package gestionDechet;


/**
 * 
 */
public enum Couleur {
    VERT,
    BLEUE,
    NOIR,
    JAUNE
}