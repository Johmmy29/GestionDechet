package adress;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import view.AcceuilController;
import view.CommerceController;
import view.ConnectionController;
import view.InscriptionController;
import view.InscriptionOuConnectionController;
import view.PoubelleController;
import view.StatistiqueController;
import gestionDechet.Compte;

import java.net.URL;

public class MainApplication extends Application {

    private Stage primaryStage;
    private Compte compte;  // Déclaration de la variable compte

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("Projet GMF 4, groupe 1");
        showInscriptionOuConnection();
    }

    public Compte getCompte() {
        return compte; // Renvoie l'objet compte actuel
    }

    public void setCompte(Compte compte) {
        this.compte = compte; // Assigne un compte à MainApplication
    }

    public void showInscriptionOuConnection() {
        try {
            URL fxmlUrl = getClass().getResource("/view/InscriptionOuConnection.fxml");
            if (fxmlUrl == null) {
                System.err.println("Impossible de trouver le fichier FXML");
                return;
            }

            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            BorderPane rootLayout = loader.load();

            // Injection de MainApplication dans le contrôleur
            InscriptionOuConnectionController controller = loader.getController();
            controller.setMainApp(this);

            Scene scene = new Scene(rootLayout);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void showAccueil(Compte compte) {
        try {
            URL fxmlUrl = getClass().getResource("/view/Accueil.fxml");
            if (fxmlUrl == null) {
                System.err.println("Fichier Accueil.fxml non trouvé");
                return;
            }

            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            AnchorPane accueilLayout = loader.load();

            AcceuilController controller = loader.getController();
            controller.setMainApp(this);
            controller.setCompte(compte);  // Passer l'objet Compte au contrôleur de l'accueil

            Scene scene = new Scene(accueilLayout);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void showPartenariat() {
        try {
            URL fxmlUrl = getClass().getResource("/view/Partenariat.fxml");
            if (fxmlUrl == null) {
                System.err.println("Fichier Partenariat.fxml non trouvé");
                return;
            }

            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            AnchorPane partenariatLayout = loader.load();

            Scene scene = new Scene(partenariatLayout);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void showCommerce() {
        try {
            URL fxmlUrl = getClass().getResource("/view/Commerce.fxml");
            if (fxmlUrl == null) {
                System.err.println("Fichier Commerce.fxml non trouvé");
                return;
            }

            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            AnchorPane commerceLayout = loader.load();

            CommerceController controller = loader.getController();
            controller.setMainApp(this);

            Scene scene = new Scene(commerceLayout);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void showPoubelle() {
        try {
            URL fxmlUrl = getClass().getResource("/view/Poubelles.fxml");
            if (fxmlUrl == null) {
                System.err.println("Fichier Poubelle.fxml non trouvé");
                return;
            }

            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            AnchorPane poubelleLayout = loader.load();

            PoubelleController controller = loader.getController();
            controller.setMainApp(this);

            Scene scene = new Scene(poubelleLayout);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void showStatistique() {
        try {
            URL fxmlUrl = getClass().getResource("/view/Statistiques.fxml");
            if (fxmlUrl == null) {
                System.err.println("Fichier Statistiques.fxml non trouvé");
                return;
            }

            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            AnchorPane statistiqueLayout = loader.load();

            StatistiqueController controller = loader.getController();
            controller.setStage(primaryStage);

            Scene scene = new Scene(statistiqueLayout);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void showMonCompte() {
        try {
            URL fxmlUrl = getClass().getResource("/view/MonCompte.fxml");
            if (fxmlUrl == null) {
                System.err.println("Fichier MonCompte.fxml non trouvé");
                return;
            }

            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            AnchorPane monCompteLayout = loader.load();

            MonCompteController controller = loader.getController();
            controller.setMainApp(this);

            Scene scene = new Scene(monCompteLayout);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void openConnectionWindow() {
        try {
            URL fxmlUrl = getClass().getResource("/view/Connection.fxml");
            if (fxmlUrl == null) {
                System.err.println("Impossible de trouver le fichier FXML Connection");
                return;
            }

            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            AnchorPane connectionLayout = loader.load();

            ConnectionController controller = loader.getController();
            controller.setMainApp(this); // Injection du Main dans le contrôleur

            Scene scene = new Scene(connectionLayout);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void openInscriptionWindow() {
        try {
            URL fxmlUrl = getClass().getResource("/view/Inscription.fxml");
            if (fxmlUrl == null) {
                System.err.println("Impossible de trouver le fichier FXML Inscription");
                return;
            }

            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            AnchorPane inscriptionLayout = loader.load();

            // Injection du contrôleur dans le fichier FXML
            InscriptionController controller = loader.getController();
            controller.setMainApp(this); // Passer l'instance de MainApplication au contrôleur

            Scene scene = new Scene(inscriptionLayout);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public static void main(String[] args) {
        launch(args);
    }
}
