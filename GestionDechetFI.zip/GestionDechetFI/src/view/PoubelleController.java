package view;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import gestionDechet.Couleur;
import gestionDechet.Poubelle;
import utils.PoubelleXMLManager;
import javafx.scene.control.TextArea;
import javafx.scene.layout.VBox;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.scene.Scene;

import java.util.ArrayList;
import java.util.List;

import adress.MainApplication;

public class PoubelleController {

    @FXML private TextField idPoubelleField;
    @FXML private TextField idPoubelleFieldCreer;
    @FXML private TextField idEmplacementField;
    @FXML private TextField couleurField;
    @FXML private TextField idPoubelleFieldSupprimer;
    @FXML private TextField idPoubelleDeplacerField;
    @FXML private TextField nouvelEmplacementField;
    @FXML private TextField idPoubelleFieldInfo;

    // Injecter le MainApplication si nécessaire
    private MainApplication mainApp;

    public void setMainApp(MainApplication mainApp) {
        this.mainApp = mainApp;
    }

    public void initialize() {
        PoubelleXMLManager.initXMLFile();
        resetFields();
    }

    // Méthodes pour gérer la création, suppression, déplacement, etc.

    private void resetFields() {
        if (idPoubelleField != null) idPoubelleField.clear();
        if (idPoubelleFieldCreer != null) idPoubelleFieldCreer.clear();
        if (idEmplacementField != null) idEmplacementField.clear();
        if (couleurField != null) couleurField.clear();
        if (idPoubelleFieldSupprimer != null) idPoubelleFieldSupprimer.clear();
        if (idPoubelleDeplacerField != null) idPoubelleDeplacerField.clear();
        if (nouvelEmplacementField != null) nouvelEmplacementField.clear();
        if (idPoubelleFieldInfo != null) idPoubelleFieldInfo.clear();
    }

    // Méthode pour collecter les poubelles pleines
    @FXML
    public void handleCollecterPoubellesPleines() {
        List<Poubelle> poubelles = PoubelleXMLManager.loadPoubelles();
        List<Poubelle> pleines = new ArrayList<>();

        for (Poubelle p : poubelles) {
            if (p.getCapaciteActuelle() >= p.getCapaciteMax()) {
                pleines.add(p);
            }
        }

        if (pleines.isEmpty()) {
            showAlert("Aucune poubelle pleine", "Toutes les poubelles sont en dessous de la capacité maximale.");
            return;
        }

        // Crée une nouvelle fenêtre avec les infos
        Stage stage = new Stage();
        stage.setTitle("Poubelles Pleines");

        StringBuilder sb = new StringBuilder();
        sb.append("Poubelles pleines détectées :\n\n");
        for (Poubelle p : pleines) {
            sb.append("ID : ").append(p.getIdPoubelle())
              .append(" | Emplacement : ").append(p.getIdEmplacement())
              .append(" | Couleur : ").append(p.getCouleur())
              .append(" | Capacité : ").append(p.getCapaciteActuelle())
              .append("/").append(p.getCapaciteMax()).append("\n");
        }

        TextArea textArea = new TextArea(sb.toString());
        textArea.setEditable(false);
        textArea.setWrapText(true);

        VBox root = new VBox(textArea);
        root.setPadding(new Insets(10));

        Scene scene = new Scene(root, 500, 300);
        stage.setScene(scene);
        stage.show();
    }

    // Méthode pour vider une poubelle
    @FXML
    public void handleViderPoubelle() {
        try {
            String idStr = idPoubelleField.getText().trim();
            if (idStr.isEmpty()) {
                showAlert("Erreur", "Veuillez entrer un ID de poubelle.");
                return;
            }

            int id = Integer.parseInt(idStr);
            List<Poubelle> poubelles = PoubelleXMLManager.loadPoubelles();

            for (Poubelle p : poubelles) {
                if (p.getIdPoubelle() == id) {
                    p.vider();  // met la capacité à 0
                    PoubelleXMLManager.saveAllPoubelles(poubelles);
                    showAlert("Succès", "La poubelle a bien été vidée !");
                    return;
                }
            }

            showAlert("Erreur", "Poubelle non trouvée !");
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erreur", "Une erreur est survenue.");
        }
        resetFields();
    }

    // Méthode pour créer une poubelle
    @FXML
    public void handleCreerPoubelle() {
        String couleurStr = couleurField.getText().trim().toUpperCase();

        try {
            Couleur couleur = Couleur.valueOf(couleurStr);  // Essaie de convertir la couleur

            int idPoubelle = Integer.parseInt(idPoubelleFieldCreer.getText().trim());
            int idEmplacement = Integer.parseInt(idEmplacementField.getText().trim());

            List<Poubelle> poubelles = PoubelleXMLManager.loadPoubelles();

            // Vérifie si une poubelle avec le même ID existe déjà
            for (Poubelle p : poubelles) {
                if (p.getIdPoubelle() == idPoubelle) {
                    showAlert("Erreur", "Une poubelle avec cet ID existe déjà.");
                    return;
                }
            }

            // Crée et ajoute la nouvelle poubelle
            Poubelle newPoubelle = new Poubelle(idPoubelle, idEmplacement, couleur);
            poubelles.add(newPoubelle);
            PoubelleXMLManager.saveAllPoubelles(poubelles);

            showAlert("Succès", "Poubelle créée avec succès !");
        } catch (IllegalArgumentException e) {
            showAlert("Couleur invalide", "Veuillez entrer une couleur valide : VERT, BLEUE, JAUNE, ou NOIR.");
        } catch (Exception e) {
            showAlert("Erreur", "Une erreur est survenue lors de la création de la poubelle.");
            e.printStackTrace();
        }
        resetFields();
    }

    // Méthode pour déplacer une poubelle
    @FXML
    public void handleDeplacerPoubelle() {
        try {
            int id = Integer.parseInt(idPoubelleDeplacerField.getText().trim());
            int nouvelEmplacement = Integer.parseInt(nouvelEmplacementField.getText().trim());

            if (!showConfirmation("Confirmation", "Voulez-vous déplacer la poubelle ID " + id + " vers l'emplacement " + nouvelEmplacement + " ?")) {
                return; // Annulé par l'utilisateur
            }

            List<Poubelle> poubelles = PoubelleXMLManager.loadPoubelles();
            for (Poubelle p : poubelles) {
                if (p.getIdPoubelle() == id) {
                    p.setIdEmplacement(nouvelEmplacement);
                    PoubelleXMLManager.saveAllPoubelles(poubelles);
                    showAlert("Succès", "Poubelle déplacée avec succès !");
                    return;
                }
            }

            showAlert("Erreur", "Poubelle non trouvée.");
        } catch (Exception e) {
            showAlert("Erreur", "Une erreur est survenue lors du déplacement.");
            e.printStackTrace();
        } finally {
            resetFields();
        }
    }

    // Méthode pour supprimer une poubelle
    @FXML
    public void handleSupprimerPoubelle() {
        try {
            int id = Integer.parseInt(idPoubelleFieldSupprimer.getText().trim());

            if (!showConfirmation("Confirmation", "Voulez-vous vraiment supprimer la poubelle ID " + id + " ?")) {
                return; // Annulé par l'utilisateur
            }

            List<Poubelle> poubelles = PoubelleXMLManager.loadPoubelles();
            poubelles.removeIf(p -> p.getIdPoubelle() == id);
            PoubelleXMLManager.saveAllPoubelles(poubelles);

            showAlert("Succès", "Poubelle supprimée avec succès !");
        } catch (Exception e) {
            showAlert("Erreur", "Une erreur est survenue lors de la suppression.");
            e.printStackTrace();
        } finally {
            resetFields();
        }
    }

    // Méthode pour afficher les informations d'une poubelle
    @FXML
    public void handleAfficherInformations() {
        try {
            String idStr = idPoubelleFieldInfo.getText().trim();
            if (idStr.isEmpty()) {
                showAlert("Erreur", "Veuillez entrer un ID de poubelle.");
                return;
            }

            int id = Integer.parseInt(idStr);
            List<Poubelle> poubelles = PoubelleXMLManager.loadPoubelles();

            for (Poubelle p : poubelles) {
                if (p.getIdPoubelle() == id) {
                    String message = "ID: " + p.getIdPoubelle() +
                                     "\nEmplacement: " + p.getIdEmplacement() +
                                     "\nCouleur: " + p.getCouleur() +
                                     "\nCapacité actuelle: " + p.getCapaciteActuelle() + " / " + p.getCapaciteMax();
                    showAlert("Informations Poubelle", message);
                    return;
                }
            }

            showAlert("Non trouvé", "Aucune poubelle avec cet ID.");
        } catch (Exception e) {
            System.out.println("❌ Erreur affichage infos.");
            e.printStackTrace();
        }
        resetFields();
    }

    // Méthode d'alerte
    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
        resetFields();
    }

    // Méthode de confirmation
    private boolean showConfirmation(String titre, String message) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle(titre);
        alert.setHeaderText(null);
        alert.setContentText(message);

        // Affiche la fenêtre et attend une réponse
        return alert.showAndWait().filter(response -> response == ButtonType.OK).isPresent();
    }
}
