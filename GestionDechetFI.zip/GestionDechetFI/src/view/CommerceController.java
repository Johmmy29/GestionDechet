package view;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import gestionDechet.Produit;
import gestionDechet.CategorieProduit;
import gestionDechet.Commerce;
import adress.MainApplication;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class CommerceController {

    @FXML private TextField nomCommerceField;
    @FXML private TextField nomProduitField;
    @FXML private TextField idProduitField;

    @FXML private Button btnSelectionner;
    @FXML private Button btnAfficherCategories;
    @FXML private Button btnAfficherProduits;
    @FXML private Button btnRetour;
    @FXML private Button btnValiderNom;
    @FXML private Button btnValiderId;

    @FXML private TableView<Produit> produitTable;
    @FXML private TableColumn<Produit, String> nomProduitColumn;
    @FXML private TableColumn<Produit, Integer> idProduitColumn;
    @FXML private TableColumn<Produit, Float> prixProduitColumn;

    private MainApplication mainApp;
    private Commerce commerce;

    private ObservableList<Produit> listeProduits = FXCollections.observableArrayList();
    private List<Commerce> commerces = new ArrayList<>();

    public void setMainApp(MainApplication mainApp) {
        this.mainApp = mainApp;

        // Ajout d'un commerce de test pour fonctionnement immédiat
        Commerce c = new Commerce(1, "Boulanger", "12 rue du Commerce", "Électronique");

        CategorieProduit cat = new CategorieProduit(1, "Électroménager", 100, 10.0f);
        cat.ajouterProduit(new Produit(1, "Grille-pain", 29.99f));
        cat.ajouterProduit(new Produit(2, "Bouilloire", 19.99f));

        c.ajouterCategorie(cat);
        commerces.add(c);
    }


    @FXML
    private void initialize() {
        nomProduitColumn.setCellValueFactory(cellData -> cellData.getValue().nomProduitProperty());
        idProduitColumn.setCellValueFactory(cellData -> cellData.getValue().idProduitProperty().asObject());
        prixProduitColumn.setCellValueFactory(cellData -> cellData.getValue().prixProduitProperty().asObject());

        produitTable.setItems(listeProduits);

        btnSelectionner.setOnAction(e -> onSelectionnerCommerce());
        btnAfficherProduits.setOnAction(e -> onAfficherProduits());
        btnAfficherCategories.setOnAction(e -> afficherCategories());
        btnValiderNom.setOnAction(e -> rechercherParNom());
        btnValiderId.setOnAction(e -> rechercherParId());
        btnRetour.setOnAction(e -> handleRetour());
    }

    private void handleRetour() {
        if (mainApp != null) {
            mainApp.showAccueil();
        }
    }

    private void onSelectionnerCommerce() {
        String nomRecherche = nomCommerceField.getText();
        commerce = commerces.stream()
                .filter(c -> c.getNom().equalsIgnoreCase(nomRecherche))
                .findFirst()
                .orElse(null);

        if (commerce != null) {
            List<Produit> produits = commerce.getCategories().stream()
                    .flatMap(cat -> cat.getProduits().stream())
                    .collect(Collectors.toList());
            listeProduits.setAll(produits);
        } else {
            listeProduits.clear();
            showAlert("Commerce introuvable.");
        }
    }

    private void onAfficherProduits() {
        if (commerce != null) {
            List<Produit> produits = commerce.getCategories().stream()
                    .flatMap(cat -> cat.getProduits().stream())
                    .collect(Collectors.toList());
            listeProduits.setAll(produits);
        } else {
            showAlert("Veuillez sélectionner un commerce.");
        }
    }

    private void afficherCategories() {
        if (commerce == null) {
            showAlert("Aucun commerce sélectionné.");
            return;
        }
        StringBuilder sb = new StringBuilder("Catégories :\n");
        for (CategorieProduit c : commerce.getCategories()) {
            sb.append("- ").append(c.getNom()).append("\n");
        }
        showAlert(sb.toString());
    }

    private void rechercherParNom() {
        String nom = nomProduitField.getText().trim().toLowerCase();
        if (nom.isEmpty()) return;

        ObservableList<Produit> filtres = listeProduits.filtered(p -> p.getNom().toLowerCase().contains(nom));
        produitTable.setItems(filtres);
    }

    private void rechercherParId() {
        try {
            int id = Integer.parseInt(idProduitField.getText().trim());
            ObservableList<Produit> filtres = listeProduits.filtered(p -> p.getIdProduit() == id);
            produitTable.setItems(filtres);
        } catch (NumberFormatException e) {
            showAlert("ID invalide !");
        }
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setContentText(message);
        alert.showAndWait();
    }
}