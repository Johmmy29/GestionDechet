package view;

import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.scene.control.Alert;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.SimpleIntegerProperty;
import java.time.LocalDate;
import java.util.List;

import gestionDechet.Contrat;
import utils.ContratXMLManager;
import adress.MainApplication;

public class PartenariatController {

    @FXML
    private TextField idContratField;

    @FXML
    private TextField idContratRenouvelerField;

    @FXML
    private TextField idCommerceField;

    @FXML
    private TextField descriptionField;

    @FXML
    private DatePicker debutDatePicker;

    @FXML
    private DatePicker finDatePicker;

    @FXML
    private DatePicker newDate;

    @FXML
    private TableView<Contrat> tablePartenariats;

    @FXML
    private TableColumn<Contrat, Integer> columnIdContrat;
    @FXML
    private TableColumn<Contrat, Integer> columnCommerce;
    @FXML
    private TableColumn<Contrat, String> columnDateDebut;
    @FXML
    private TableColumn<Contrat, String> columnDateFin;
    @FXML
    private TableColumn<Contrat, String> columnDescription;

    private ObservableList<Contrat> contrats = FXCollections.observableArrayList();
    private MainApplication mainApp;

    // Injecter MainApplication
    public void setMainApp(MainApplication mainApp) {
        this.mainApp = mainApp;
    }

    public void initialize() {
        ContratXMLManager.initXMLFile();
        List<Contrat> listeInitiale = ContratXMLManager.loadContrats();
        contrats.setAll(listeInitiale);

        columnIdContrat.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getIdContrat()).asObject());
        columnCommerce.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getIdCommerce()).asObject());
        columnDateDebut.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getDateDebut().toString()));
        columnDateFin.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getDateFin().toString()));
        columnDescription.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getReglesUtilisation()));

        tablePartenariats.setItems(contrats);
    }

    @FXML
    public void handleCreerNouveauContrat() {
        try {
            String idContratStr = idContratField.getText().trim();
            String idCommerceStr = idCommerceField.getText().trim();
            String description = descriptionField.getText().trim();
            LocalDate debutDate = debutDatePicker.getValue();
            LocalDate finDate = finDatePicker.getValue();

            if (idContratStr.isEmpty() || idCommerceStr.isEmpty() || description.isEmpty() || debutDate == null || finDate == null) {
                showAlert("Champs manquants", "Veuillez remplir tous les champs !");
                return;
            }

            int idContrat = Integer.parseInt(idContratStr);
            int idCommerce = Integer.parseInt(idCommerceStr);

            Contrat nouveauContrat = new Contrat(idContrat, idCommerce, debutDate, finDate, description);
            contrats.add(nouveauContrat);

            ContratXMLManager.saveAllContrats(contrats);
            showAlert("Succès", "Nouveau contrat créé et sauvegardé !");

            tablePartenariats.refresh();

            idContratField.clear();
            idCommerceField.clear();
            descriptionField.clear();
            debutDatePicker.setValue(null);
            finDatePicker.setValue(null);

        } catch (NumberFormatException e) {
            showAlert("Erreur", "L'ID doit être un nombre entier !");
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erreur interne", "Une erreur est survenue lors de la création du contrat.");
        }
    }

    @FXML
    public void handleSupprimerContrat() {
        Contrat contratSelectionne = tablePartenariats.getSelectionModel().getSelectedItem();
        if (contratSelectionne != null) {
            contrats.remove(contratSelectionne);
            ContratXMLManager.saveAllContrats(contrats);
            showAlert("Succès", "Contrat supprimé !");
        } else {
            showAlert("Information", "Veuillez sélectionner un contrat à supprimer.");
        }
    }

    @FXML
    public void handleRenouvelerContrat() {
        try {
            String idContratStr = idContratRenouvelerField.getText().trim();
            if (idContratStr.isEmpty()) {
                showAlert("Champ vide", "L'ID du contrat ne peut pas être vide.");
                return;
            }

            int idContrat = Integer.parseInt(idContratStr);
            LocalDate nouvelleDateFin = newDate.getValue();
            if (nouvelleDateFin == null) {
                showAlert("Date manquante", "Veuillez sélectionner une nouvelle date de fin.");
                return;
            }

            boolean contratRenouvele = false;
            for (Contrat contrat : contrats) {
                if (contrat.getIdContrat() == idContrat) {
                    contratRenouvele = contrat.renouvelerContrat(nouvelleDateFin);
                    break;
                }
            }

            if (contratRenouvele) {
                showAlert("Succès", "Contrat renouvelé avec succès !");
                ContratXMLManager.saveAllContrats(contrats);
            } else {
                showAlert("Erreur", "Aucun contrat trouvé avec l'ID " + idContrat);
            }

            tablePartenariats.refresh();
            idContratRenouvelerField.clear();
            newDate.setValue(null);

        } catch (NumberFormatException e) {
            showAlert("Erreur", "L'ID du contrat doit être un nombre entier valide.");
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erreur interne", "Une erreur est survenue lors du renouvellement du contrat.");
        }
    }

    @FXML
    public void handleRetour() {
        if (mainApp != null && mainApp.getCompte() != null) {  // S'assurer que le compte existe
            mainApp.showAccueil(mainApp.getCompte());  // Passe le compte à showAccueil
        }
    }


    private void showAlert(String titre, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titre);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
