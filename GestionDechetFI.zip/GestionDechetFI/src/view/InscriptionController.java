package view;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import adress.MainApplication;
import ConnexionDAO.UtilisateurDAO;  // Assurez-vous d'importer le DAO

public class InscriptionController {

    @FXML
    private Button btnRetour;

    @FXML
    private Button btnValider;

    @FXML
    private TextField idField;

    @FXML
    private TextField nomField;  // Ajout du champ pour le nom

    @FXML
    private TextField emailField;

    @FXML
    private TextField passwordField;

    private MainApplication mainApp;

    // Déclaration du DAO
    private UtilisateurDAO utilisateurDAO;

    public void setMainApp(MainApplication mainApp) {
        this.mainApp = mainApp;
    }

    @FXML
    private void initialize() {
        utilisateurDAO = new UtilisateurDAO();  // Initialisation du DAO

        btnRetour.setOnAction(event -> handleRetour());
        btnValider.setOnAction(event -> handleValider());
    }

    private void handleRetour() {
        if (mainApp != null) {
            mainApp.showInscriptionOuConnection();
        } else {
            System.out.println(">>> ERREUR : mainApp est null");
        }
    }

    private void handleValider() {
        try {
            String id = idField.getText().trim();
            String nom = nomField.getText().trim();  // Récupérer le nom
            String email = emailField.getText().trim();
            String password = passwordField.getText().trim();

            if (id.isEmpty() || nom.isEmpty() || email.isEmpty() || password.isEmpty()) {
                showAlert(Alert.AlertType.ERROR, "Erreur", "Tous les champs doivent être remplis !");
                return;
            }

            // Vérification si l'ID est un entier
            try {
                Integer.parseInt(id);  // Essaie de convertir l'ID en entier
            } catch (NumberFormatException e) {
                showAlert(Alert.AlertType.ERROR, "Erreur", "L'ID doit être un nombre entier.");
                return;
            }

            if (!email.matches("^[\\w.-]+@[\\w.-]+\\.\\w{2,}$")) {
                showAlert(Alert.AlertType.ERROR, "Email invalide", "Veuillez entrer une adresse email valide.");
                return;
            }

            if (password.length() < 6) {
                showAlert(Alert.AlertType.ERROR, "Mot de passe trop court", "Le mot de passe doit contenir au moins 6 caractères.");
                return;
            }

            // Vérifier si l'utilisateur existe déjà dans la base de données
            if (utilisateurDAO.verifierUtilisateur(id, password)) {
                showAlert(Alert.AlertType.ERROR, "ID déjà utilisé", "Un utilisateur avec cet ID existe déjà.");
                return;
            }

            // Ajouter l'utilisateur à la base de données
            utilisateurDAO.ajouterUtilisateur(id, nom, email, password); // Passer le nom

            showAlert(Alert.AlertType.INFORMATION, "Succès", "Inscription réussie !");
            handleRetour(); // Retour à l'écran de connexion

        } catch (Exception e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Erreur interne", "Une erreur est survenue lors de l'inscription.");
        }
    }

    private void showAlert(Alert.AlertType type, String title, String message) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
