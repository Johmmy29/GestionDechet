package ConnexionDAO;

import java.sql.*;
import ConnexionBDD.DatabaseConnection;
import gestionDechet.Compte;

public class UtilisateurDAO {

    public boolean verifierUtilisateur(String id, String password) {
        String query = "SELECT * FROM utilisateurs WHERE id = ? AND motdepasse = ?";
        boolean utilisateurExiste = false;

        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, id);  // Remplir l'ID de l'utilisateur
            stmt.setString(2, password); // Remplir le mot de passe
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                utilisateurExiste = true;  // Si un utilisateur correspondant est trouvé
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return utilisateurExiste; // Retourne true si l'utilisateur est trouvé
    }

    // Méthode pour ajouter un nouvel utilisateur à la base de données
    public void ajouterUtilisateur(String id, String nom, String email, String password) {
        String query = "INSERT INTO utilisateurs (id, nom, email, motdepasse) VALUES (?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, Integer.parseInt(id));  // ID doit être un entier
            stmt.setString(2, nom);  // Nom de l'utilisateur
            stmt.setString(3, email);  // Email de l'utilisateur
            stmt.setString(4, password);  // Mot de passe

            stmt.executeUpdate();  // Exécuter la commande SQL pour insérer l'utilisateur
            System.out.println("Utilisateur ajouté !");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Méthode pour récupérer les données de l'utilisateur et créer un objet Compte
    public Compte getCompteById(String id) {
        String query = "SELECT * FROM utilisateurs WHERE id = ?";
        Compte compte = null;

        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, id); // Remplir l'ID de l'utilisateur
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String email = rs.getString("email");
                String motDePasse = rs.getString("motdepasse");
                // Créer l'objet Compte avec les données récupérées
                compte = new Compte(Integer.parseInt(id), email, motDePasse);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return compte; // Retourne l'objet Compte
    }
}
