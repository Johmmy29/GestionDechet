package ConnexionDAO;

import java.sql.*;

import ConnexionBDD.DatabaseConnection;

public class ProduitDAO {

    // Ajouter un produit dans la base de données
    public void ajouterProduit(String nom, double prix) {
        String query = "INSERT INTO produits (nom, prix) VALUES (?, ?)";

        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, nom);
            stmt.setDouble(2, prix);

            stmt.executeUpdate(); // Exécuter la commande SQL
            System.out.println("Produit ajouté !");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Lire tous les produits de la base de données
    public void afficherProduits() {
        String query = "SELECT * FROM produits";

        try (Connection conn = DatabaseConnection.connect();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String nom = rs.getString("nom");
                double prix = rs.getDouble("prix");

                System.out.println("ID: " + id + ", Nom: " + nom + ", Prix: " + prix);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Mettre à jour un produit
    public void mettreAJourProduit(int id, String nom, double prix) {
        String query = "UPDATE produits SET nom = ?, prix = ? WHERE id = ?";

        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, nom);
            stmt.setDouble(2, prix);
            stmt.setInt(3, id);

            stmt.executeUpdate(); // Exécuter la commande SQL
            System.out.println("Produit mis à jour !");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Supprimer un produit
    public void supprimerProduit(int id) {
        String query = "DELETE FROM produits WHERE id = ?";

        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, id);
            stmt.executeUpdate(); // Exécuter la commande SQL
            System.out.println("Produit supprimé !");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
