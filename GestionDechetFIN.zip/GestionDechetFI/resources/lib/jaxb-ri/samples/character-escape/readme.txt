This example shows how you can use a JAXB RI specific marshaller property
to change the default character escaping behavior.