package utils;

import gestionDechet.Contrat;
import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ContratXMLManager {

    private static final String FILE_PATH = "data/contrats.xml";  // 🔄 Dossier dédié

    public static void initXMLFile() {
        try {
            File file = new File(FILE_PATH);
            File parentDir = file.getParentFile();
            if (!parentDir.exists()) {
                parentDir.mkdirs();  // 📁 Crée "data/" si nécessaire
            }

            if (!file.exists()) {
                DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
                Document doc = dBuilder.newDocument();

                Element rootElement = doc.createElement("contrats");
                doc.appendChild(rootElement);

                saveDocument(doc);
                System.out.println("✅ Fichier XML créé : " + FILE_PATH);
            } else {
                System.out.println("📂 Fichier XML déjà existant : " + FILE_PATH);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static List<Contrat> loadContrats() {
        List<Contrat> contrats = new ArrayList<>();
        try {
            File file = new File(FILE_PATH);
            if (!file.exists()) return contrats;

            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(file);

            NodeList nodeList = doc.getElementsByTagName("contrat");

            for (int i = 0; i < nodeList.getLength(); i++) {
                Node node = nodeList.item(i);
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                    Element element = (Element) node;

                    int idContrat = Integer.parseInt(element.getElementsByTagName("idContrat").item(0).getTextContent());
                    int idCommerce = Integer.parseInt(element.getElementsByTagName("idCommerce").item(0).getTextContent());
                    LocalDate dateDebut = LocalDate.parse(element.getElementsByTagName("dateDebut").item(0).getTextContent());
                    LocalDate dateFin = LocalDate.parse(element.getElementsByTagName("dateFin").item(0).getTextContent());
                    String description = element.getElementsByTagName("description").item(0).getTextContent();

                    contrats.add(new Contrat(idContrat, idCommerce, dateDebut, dateFin, description));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return contrats;
    }

    public static void saveAllContrats(List<Contrat> contrats) {
        try {
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.newDocument();

            Element rootElement = doc.createElement("contrats");
            doc.appendChild(rootElement);

            for (Contrat contrat : contrats) {
                Element contratEl = doc.createElement("contrat");

                createChild(doc, contratEl, "idContrat", String.valueOf(contrat.getIdContrat()));
                createChild(doc, contratEl, "idCommerce", String.valueOf(contrat.getIdCommerce()));
                createChild(doc, contratEl, "dateDebut", contrat.getDateDebut().toString());
                createChild(doc, contratEl, "dateFin", contrat.getDateFin().toString());
                createChild(doc, contratEl, "description", contrat.getReglesUtilisation());

                rootElement.appendChild(contratEl);
            }

            saveDocument(doc);
            System.out.println("💾 Contrats sauvegardés dans le fichier XML.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void createChild(Document doc, Element parent, String name, String value) {
        Element elem = doc.createElement(name);
        elem.appendChild(doc.createTextNode(value));
        parent.appendChild(elem);
    }

    private static void saveDocument(Document doc) throws TransformerException {
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");

        DOMSource source = new DOMSource(doc);
        StreamResult result = new StreamResult(new File(FILE_PATH));

        transformer.transform(source, result);
    }
}
