package view;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import gestionDechet.Produit;
import gestionDechet.CategorieProduit;
import gestionDechet.Commerce;
import gestionDechet.Compte;
import ConnexionDAO.ProduitDAO;
import ConnexionDAO.CategorieDAO;
import ConnexionDAO.CommerceDAO;
import adress.MainApplication;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class CommerceController {

    @FXML private TextField nomCommerceField;
    @FXML private TextField nomProduitField;
    @FXML private TextField idProduitField;

    @FXML private Button btnAfficherCategories;
    @FXML private Button btnAfficherProduits;
    @FXML private Button btnRetour;
    @FXML private Button btnValiderNom;
    @FXML private Button btnValiderId;

    @FXML private TableView<Produit> produitTable;
    @FXML private TableColumn<Produit, String> nomProduitColumn;
    @FXML private TableColumn<Produit, Integer> idProduitColumn;
    @FXML private TableColumn<Produit, Float> prixProduitColumn;

    private MainApplication mainApp;
    private Commerce commerce;
    private Compte compte;  // Variable pour stocker l'objet Compte

    // Liste des commerces simulée pour le test
    private List<Commerce> commerces = new ArrayList<>();
    private ObservableList<Produit> listeProduits = FXCollections.observableArrayList();

    // Méthode pour injecter l'objet Compte dans le contrôleur
    public void setCompte(Compte compte) {
        this.compte = compte;
    }

    // Injecter l'objet MainApplication dans le contrôleur
    public void setMainApp(MainApplication mainApp) {
        this.mainApp = mainApp;
    }

    @FXML
    private void initialize() {
        nomProduitColumn.setCellValueFactory(cellData -> cellData.getValue().nomProduitProperty());
        idProduitColumn.setCellValueFactory(cellData -> cellData.getValue().idProduitProperty().asObject());
        prixProduitColumn.setCellValueFactory(cellData -> cellData.getValue().prixProduitProperty().asObject());

        produitTable.setItems(listeProduits);

        btnAfficherCategories.setOnAction(e -> afficherCategories());
        btnAfficherProduits.setOnAction(e -> onAfficherProduits());
        btnValiderNom.setOnAction(e -> rechercherParNom());
        btnValiderId.setOnAction(e -> rechercherParId());
        btnRetour.setOnAction(e -> handleRetour());
    }

    private void handleRetour() {
        if (mainApp != null) {
            mainApp.showAccueil();
        }
    }

    private void onAfficherProduits() {
        String nomRecherche = nomCommerceField.getText().trim().toLowerCase();
        if (!nomRecherche.isEmpty()) {
            CommerceDAO commerceDAO = new CommerceDAO();
            int idCommerce = commerceDAO.getIdCommerceByName(nomRecherche);
            if (idCommerce != -1) {
                ProduitDAO produitDAO = new ProduitDAO();
                List<Produit> produits = produitDAO.getProduitsByCommerce(idCommerce);
                listeProduits.setAll(produits);
            } else {
                showAlert("Aucun commerce trouvé.");
            }
        }
    }

    private void afficherCategories() {
        String nomRecherche = nomCommerceField.getText().trim().toLowerCase();
        if (!nomRecherche.isEmpty()) {
            CommerceDAO commerceDAO = new CommerceDAO();
            int idCommerce = commerceDAO.getIdCommerceByName(nomRecherche);
            if (idCommerce != -1) {
                CategorieDAO categorieDAO = new CategorieDAO();
                ResultSet rs = categorieDAO.getCategoriesByCommerce(idCommerce);

                try {
                    StringBuilder sb = new StringBuilder("Catégories :\n");
                    while (rs.next()) {
                        sb.append("- ").append(rs.getString("nom_categorie")).append("\n");
                    }
                    showAlert(sb.toString());
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            } else {
                showAlert("Aucun commerce trouvé.");
            }
        }
    }

    private void rechercherParNom() {
        String nom = nomProduitField.getText().trim().toLowerCase();
        if (nom.isEmpty()) return;

        ObservableList<Produit> filtres = listeProduits.filtered(p -> p.getNom().toLowerCase().contains(nom));
        produitTable.setItems(filtres);
    }

    private void rechercherParId() {
        try {
            int id = Integer.parseInt(idProduitField.getText().trim());
            ObservableList<Produit> filtres = listeProduits.filtered(p -> p.getIdProduit() == id);
            produitTable.setItems(filtres);
        } catch (NumberFormatException e) {
            showAlert("ID invalide !");
        }
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setContentText(message);
        alert.showAndWait();
    }
}
