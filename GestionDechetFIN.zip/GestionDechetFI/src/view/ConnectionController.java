package view;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import adress.MainApplication;
import ConnexionDAO.UtilisateurDAO;
import gestionDechet.Compte;

public class ConnectionController {

    @FXML
    private Button btnRetour;

    @FXML
    private Button btnValider;

    @FXML
    private TextField txtID;

    @FXML
    private TextField txtPassword;

    private MainApplication mainApp;
    private UtilisateurDAO utilisateurDAO;  // Assurez-vous que UtilisateurDAO gère la connexion MySQL
    private Compte compte;

    public void setMainApp(MainApplication mainApp) {
        this.mainApp = mainApp;
    }

    public void setCompte(Compte compte) {
        this.compte = compte;
    }

    public Compte getCompte() {
        return this.compte;
    }

    @FXML
    private void initialize() {
        utilisateurDAO = new UtilisateurDAO();  // Initialisation de l'accès à la base de données

        // Événement pour le bouton retour
        btnRetour.setOnAction(event -> {
            if (mainApp != null) {
                mainApp.showInscriptionOuConnection();
            }
        });

        // Événement pour le bouton valider (connexion)
        btnValider.setOnAction(event -> handleValider());
    }

    private void handleValider() {
        String email = txtID.getText().trim();  // Assurez-vous d'utiliser 'email' au lieu de 'id'
        String password = txtPassword.getText().trim();

        if (email.isEmpty() || password.isEmpty()) {
            showAlert("Erreur", "Veuillez remplir tous les champs.");
            return;
        }

        // Afficher les informations dans la console pour déboguer
        System.out.println("Tentative de connexion avec l'email : " + email);
        System.out.println("Mot de passe : " + password);

        // Vérification de l'utilisateur avec la base de données
        if (utilisateurDAO.verifierUtilisateur(email, password)) {
            // Une fois l'utilisateur validé, récupérer les informations de la base de données
            compte = utilisateurDAO.getCompteByEmailAndPassword(email, password);  // Assurez-vous que cette méthode existe dans UtilisateurDAO

            if (compte != null) {
                showAlert("Succès", "Connexion réussie !");
                System.out.println(">>> Connexion OK, on affiche l'accueil");

                // Passer le compte à la page Accueil
                if (mainApp != null) {
                    mainApp.setCompte(compte);  // Sauvegarder le compte dans MainApplication
                    mainApp.showAccueil();  // Passer le compte à la page Accueil
                }
            } else {
                showAlert("Erreur", "Impossible de récupérer les informations du compte.");
            }
        } else {
            showAlert("Erreur", "Email ou mot de passe incorrect.");
        }
    }

    private void showAlert(String titre, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titre);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
