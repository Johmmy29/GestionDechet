package view;

import adress.MainApplication;
import gestionDechet.Compte;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class AcceuilController {

    @FXML
    private Button btnRetour;

    @FXML
    private Button btnPartenariat;

    @FXML
    private Button btnCommerce;

    @FXML
    private Button btnPoubelle;

    @FXML
    private Button btnStatistique;

    @FXML
    private Button btnMonCompte;

    @FXML
    private Label welcomeLabel;  // Afficher un message de bienvenue

    private MainApplication mainApp;
    private Compte compte;

    public void setMainApp(MainApplication mainApp) {
        this.mainApp = mainApp;
    }

    public void setCompte(Compte compte) {
        this.compte = compte;
        if (welcomeLabel != null) {
            welcomeLabel.setText("Bienvenue, " + compte.getEmail()); // Afficher l'email de l'utilisateur
        }
    }

    @FXML
    private void initialize() {
        btnRetour.setOnAction(event -> handleRetour());
        btnPartenariat.setOnAction(event -> mainApp.showPartenariat());
        btnCommerce.setOnAction(event -> mainApp.showCommerce());
        btnPoubelle.setOnAction(event -> mainApp.showPoubelle());
        btnStatistique.setOnAction(event -> mainApp.showStatistique());
        btnMonCompte.setOnAction(event -> mainApp.showNotreCompte());
    }
    @FXML
    private void handleShowNotreCompte() {
        if (mainApp != null) {
            mainApp.showNotreCompte();  // Navigate to NotreCompte page
        }
    }

@FXML
    private void handleRetour() {
        if (mainApp != null) {
            mainApp.showInscriptionOuConnection();  // Retour à la page InscriptionOuConnection
        }
    }
}