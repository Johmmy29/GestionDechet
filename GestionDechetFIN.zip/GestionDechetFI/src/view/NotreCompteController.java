package view;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import adress.MainApplication;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class NotreCompteController {

    @FXML
    private ComboBox<String> comboBox;  // Type de Déchet ComboBox

    @FXML
    private ComboBox<String> comboBox1;  // Vider Dépot ComboBox

    @FXML
    private TextField quantitesField;  // Quantité TextField

    @FXML
    private Button btnValider;

    @FXML
    private Button btnRetour;

    private MainApplication mainApp;

    // Injecter MainApplication dans ce contrôleur
    public void setMainApp(MainApplication mainApp) {
        this.mainApp = mainApp;
    }

    // Initialisation de la page : Remplir les ComboBox avec des données (exemples)
    @FXML
    private void initialize() {
        comboBox.getItems().addAll("Type 1", "Type 2", "Type 3");  // Ajoutez des types réels ici
        comboBox1.getItems().addAll("Type A", "Type B", "Type C");  // Ajoutez des types réels ici

        // Handle button actions
        btnValider.setOnAction(e -> handleValider());
        btnRetour.setOnAction(e -> handleRetour());
    }

    // Fonction pour valider les informations et enregistrer dans la base de données
    private void handleValider() {
        String quantites = quantitesField.getText().trim();
        String selectedDechetType = comboBox.getSelectionModel().getSelectedItem();
        String selectedDepotType = comboBox1.getSelectionModel().getSelectedItem();

        if (quantites.isEmpty() || selectedDechetType == null || selectedDepotType == null) {
            showAlert("Erreur", "Veuillez remplir tous les champs.");
            return;
        }

        // Enregistrer dans la base de données
        saveDechetToDatabase(quantites, selectedDechetType, selectedDepotType);
    }

    // Méthode pour enregistrer un déchet dans la base de données
    private void saveDechetToDatabase(String quantites, String dechetType, String depotType) {
        String url = "jdbc:mysql://localhost:3306/gestion_dechets";  // Changez si nécessaire
        String username = "root";  // Changez si nécessaire
        String password = "rootroot";  // Changez si nécessaire

        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            String query = "INSERT INTO dechets (quantite, type_dechet, type_depot) VALUES (?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(query)) {
                statement.setDouble(1, Double.parseDouble(quantites));
                statement.setString(2, dechetType);
                statement.setString(3, depotType);
                
                int rowsAffected = statement.executeUpdate();  // Exécute l'insertion
                if (rowsAffected > 0) {
                    showAlert("Succès", "Les données ont été enregistrées !");
                } else {
                    showAlert("Erreur", "L'enregistrement a échoué.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Erreur", "Une erreur s'est produite lors de l'enregistrement.");
        }
    }

    // Fonction pour gérer le bouton retour
    private void handleRetour() {
        if (mainApp != null) {
            mainApp.showAccueil();  // Retour à la page d'accueil
        }
    }

    // Fonction pour afficher une alerte
    private void showAlert(String title, String message) {
        javafx.scene.control.Alert alert = new javafx.scene.control.Alert(javafx.scene.control.Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
