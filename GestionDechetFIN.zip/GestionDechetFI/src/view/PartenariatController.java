package view;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.control.TableView;
import javafx.scene.control.TableColumn;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.sql.Date;
import java.time.LocalDate;

import ConnexionDAO.ContratDAO;
import gestionDechet.Contrat;
import adress.MainApplication;     // Assurez-vous que MainApplication est bien importé
import gestionDechet.Compte;      // Assurez-vous que Compte est bien importé

public class PartenariatController {

    @FXML
    private TextField idContratField;

    @FXML
    private TextField idContratRenouvelerField;

    @FXML
    private TextField idCommerceField;

    @FXML
    private TextField descriptionField;

    @FXML
    private DatePicker debutDatePicker;

    @FXML
    private DatePicker finDatePicker;

    @FXML
    private DatePicker newDate;

    @FXML
    private TableView<Contrat> tablePartenariats;

    @FXML
    private TableColumn<Contrat, Integer> columnIdContrat;
    @FXML
    private TableColumn<Contrat, Integer> columnCommerce;
    @FXML
    private TableColumn<Contrat, String> columnDateDebut;
    @FXML
    private TableColumn<Contrat, String> columnDateFin;
    @FXML
    private TableColumn<Contrat, String> columnDescription;

    @FXML
    private TextField idContratSupprField;  // Champ pour saisir l'ID du contrat à supprimer

    private ObservableList<Contrat> contrats = FXCollections.observableArrayList();

    private MainApplication mainApp;  // Déclaration pour MainApplication
    private Compte compte;  // Déclaration pour Compte

    // Méthode pour afficher les alertes
    private void showAlert(String titre, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titre);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    // Méthode pour ajouter un contrat dans la BDD
    @FXML
    public void handleCreerNouveauContrat() {
        try {
            // Récupérer l'ID du contrat saisi par l'utilisateur
            String idContratStr = idContratField.getText().trim();
            String idCommerceStr = idCommerceField.getText().trim();
            String description = descriptionField.getText().trim();
            LocalDate debutDate = debutDatePicker.getValue();
            LocalDate finDate = finDatePicker.getValue();

            if (idContratStr.isEmpty() || idCommerceStr.isEmpty() || description.isEmpty() || debutDate == null || finDate == null) {
                showAlert("Champs manquants", "Veuillez remplir tous les champs !");
                return;
            }

            // Convertir l'ID du contrat en entier
            int idContrat = Integer.parseInt(idContratStr);
            int idCommerce = Integer.parseInt(idCommerceStr);

            // Créer un contrat avec l'ID fourni par l'utilisateur
            Contrat nouveauContrat = new Contrat(idContrat, idCommerce, debutDate, finDate, description);

            // Utiliser ContratDAO pour insérer un nouveau contrat dans la base de données
            ContratDAO contratDAO = new ContratDAO();
            contratDAO.ajouterContrat(nouveauContrat);  // Ajouter dans MySQL

            showAlert("Succès", "Contrat créé et sauvegardé dans la base de données !");

            // Réactualiser la TableView
            contrats.add(nouveauContrat);
            tablePartenariats.setItems(contrats);

            // Réinitialiser les champs
            idContratField.clear();
            idCommerceField.clear();
            descriptionField.clear();
            debutDatePicker.setValue(null);
            finDatePicker.setValue(null);
        } catch (NumberFormatException e) {
            showAlert("Erreur", "L'ID doit être un nombre entier !");
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erreur interne", "Une erreur est survenue lors de la création du contrat.");
        }
    }

    // Méthode pour supprimer un contrat de la BDD
    @FXML
    public void handleSupprimerContrat() {
        String idContratStr = idContratSupprField.getText().trim();
        if (idContratStr.isEmpty()) {
            showAlert("Champ vide", "L'ID du contrat ne peut pas être vide.");
            return;
        }

        try {
            int idContrat = Integer.parseInt(idContratStr);

            // Utiliser ContratDAO pour supprimer le contrat de la base de données
            ContratDAO contratDAO = new ContratDAO();
            contratDAO.supprimerContrat(idContrat);  // Suppression dans la BDD

            showAlert("Succès", "Contrat supprimé avec succès !");
            tablePartenariats.getItems().removeIf(contrat -> contrat.getIdContrat() == idContrat);

            idContratSupprField.clear();  // Effacer le champ après la suppression
        } catch (NumberFormatException e) {
            showAlert("Erreur", "L'ID du contrat doit être un nombre entier.");
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erreur interne", "Une erreur est survenue lors de la suppression du contrat.");
        }
    }

    // Méthode pour renouveler un contrat dans la BDD
    @FXML
    public void handleRenouvelerContrat() {
        try {
            String idContratStr = idContratRenouvelerField.getText().trim();
            if (idContratStr.isEmpty()) {
                showAlert("Champ vide", "L'ID du contrat ne peut pas être vide.");
                return;
            }

            int idContrat = Integer.parseInt(idContratStr);
            LocalDate nouvelleDateFin = newDate.getValue();
            if (nouvelleDateFin == null) {
                showAlert("Date manquante", "Veuillez sélectionner une nouvelle date de fin.");
                return;
            }

            // Utiliser ContratDAO pour renouveler le contrat
            ContratDAO contratDAO = new ContratDAO();
            boolean contratRenouvele = contratDAO.renouvelerContrat(idContrat, nouvelleDateFin);  // Mise à jour dans la BDD

            if (contratRenouvele) {
                showAlert("Succès", "Contrat renouvelé avec succès !");
            } else {
                showAlert("Erreur", "Aucun contrat trouvé avec l'ID " + idContrat);
            }

            tablePartenariats.refresh();
            idContratRenouvelerField.clear();
            newDate.setValue(null);
        } catch (NumberFormatException e) {
            showAlert("Erreur", "L'ID du contrat doit être un nombre entier valide.");
        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Erreur interne", "Une erreur est survenue lors du renouvellement du contrat.");
        }
    }

    // Méthodes pour lier MainApplication et Compte
    public void setMainApp(MainApplication mainApp) {
        this.mainApp = mainApp;
    }

    public void setCompte(Compte compte) {
        this.compte = compte;
    }

    // Retour à l'accueil
    @FXML
    public void handleRetour() {
        if (mainApp != null) {
            mainApp.showAccueil();  // Rediriger vers la page d'accueil
        }
    }
}
