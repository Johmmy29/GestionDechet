package ConnexionDAO;

import java.sql.*;
import gestionDechet.Compte;

public class UtilisateurDAO {

    private Connection connection;

    public UtilisateurDAO() {
        try {
            // Assurez-vous de remplacer ces valeurs par les vôtres
            String url = "jdbc:mysql://localhost:3306/gestion_dechets";
            String username = "root";
            String password = "rootroot";
            
            // Connexion à la base de données
            connection = DriverManager.getConnection(url, username, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Méthode pour vérifier si un utilisateur existe avec l'email et mot de passe
    public boolean verifierUtilisateur(String email, String motDePasse) {
        try {
            String query = "SELECT * FROM comptes WHERE email = ? AND mot_de_passe = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, email);
            statement.setString(2, motDePasse);

            System.out.println("Executing query: " + statement.toString());  // Debugging line to see the query

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                return true;  // Utilisateur trouvé
            } else {
                System.out.println("Aucun utilisateur trouvé pour l'email: " + email);  // Debugging line
                return false;  // Utilisateur non trouvé
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    // Méthode pour récupérer un compte d'utilisateur à partir de l'email et du mot de passe
    public Compte getCompteByEmailAndPassword(String email, String motDePasse) {
        try {
            // Interroger la table 'comptes' avec la colonne 'mot_de_passe'
            String query = "SELECT * FROM comptes WHERE email = ? AND mot_de_passe = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, email);
            statement.setString(2, motDePasse);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                int id = resultSet.getInt("id");
                String emailResult = resultSet.getString("email");
                String motDePasseResult = resultSet.getString("mot_de_passe");

                // Créez un objet Compte avec les données récupérées
                return new Compte(id, emailResult, motDePasseResult);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;  // Si aucun compte n'est trouvé, retourne null
    }

    // Méthode pour ajouter un nouvel utilisateur dans la base de données
    public boolean ajouterUtilisateur(String email, String motDePasse, String nom) {
        try {
            // Vérification si l'email est déjà utilisé
            String checkQuery = "SELECT * FROM comptes WHERE email = ?";
            PreparedStatement checkStatement = connection.prepareStatement(checkQuery);
            checkStatement.setString(1, email);
            ResultSet checkResult = checkStatement.executeQuery();

            if (checkResult.next()) {
                System.out.println("L'email est déjà utilisé : " + email);
                return false;  // L'email existe déjà
            }

            // Insertion de l'utilisateur dans la table 'comptes'
            String query = "INSERT INTO comptes (email, mot_de_passe) VALUES (?, ?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, email);
            statement.setString(2, motDePasse);  // Vous devez peut-être hasher le mot de passe ici pour plus de sécurité

            int rowsAffected = statement.executeUpdate();  // Exécute la requête d'insertion
            System.out.println("Utilisateur ajouté dans la table 'comptes'. Email : " + email);
            return rowsAffected > 0;  // Si l'insertion a réussi, retourne true
        } catch (SQLException e) {
            e.printStackTrace();
            return false;  // En cas d'erreur, retourne false
        }
    }
}