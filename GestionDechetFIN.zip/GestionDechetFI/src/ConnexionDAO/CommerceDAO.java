package ConnexionDAO;

import java.sql.*;
import ConnexionBDD.DatabaseConnection;

public class CommerceDAO {

    public int getIdCommerceByName(String nomCommerce) {
        int id = -1;
        String query = "SELECT id_commerce FROM commerces WHERE nom_commerce = ?";

        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, nomCommerce);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                id = rs.getInt("id_commerce");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return id;
    }
}
