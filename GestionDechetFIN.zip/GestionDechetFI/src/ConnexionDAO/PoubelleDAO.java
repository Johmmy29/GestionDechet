package ConnexionDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import ConnexionBDD.DatabaseConnection;
import gestionDechet.Poubelle;
import gestionDechet.Couleur;

public class PoubelleDAO {

    private Connection connection;

    public PoubelleDAO() {
        try {
            connection = DatabaseConnection.connect();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Ajouter une poubelle
    public void ajouterPoubelle(Poubelle poubelle) {
        String sql = "INSERT INTO poubelle (id_poubelle, capacite_actuelle, id_emplacement, couleur) VALUES (?, ?, ?, ?)";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, poubelle.getIdPoubelle());
            statement.setFloat(2, poubelle.getCapaciteActuelle());
            statement.setInt(3, poubelle.getIdEmplacement());
            statement.setString(4, poubelle.getCouleur().toString());

            statement.executeUpdate();
            System.out.println("✅ Poubelle ajoutée dans la base !");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Supprimer une poubelle
    public void supprimerPoubelle(int idPoubelle) {
        String sql = "DELETE FROM poubelle WHERE id_poubelle = ?";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, idPoubelle);
            statement.executeUpdate();
            System.out.println("✅ Poubelle supprimée !");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Déplacer une poubelle
    public void deplacerPoubelle(int idPoubelle, int nouvelEmplacement) {
        String sql = "UPDATE poubelle SET id_emplacement = ? WHERE id_poubelle = ?";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, nouvelEmplacement);
            statement.setInt(2, idPoubelle);
            statement.executeUpdate();
            System.out.println("✅ Poubelle déplacée !");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Récupérer une poubelle par son ID
    public Poubelle getPoubelleById(int idPoubelle) {
        String sql = "SELECT * FROM poubelle WHERE id_poubelle = ?";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, idPoubelle);

            ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                return new Poubelle(
                    rs.getInt("id_poubelle"),
                    rs.getInt("id_emplacement"),
                    Couleur.valueOf(rs.getString("couleur"))
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Récupérer toutes les poubelles pleines
    public List<Poubelle> getPoubellesPleines() {
        List<Poubelle> pleines = new ArrayList<>();
        String sql = "SELECT * FROM poubelle WHERE capacite_actuelle >= 1000";

        try (PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet rs = statement.executeQuery()) {

            while (rs.next()) {
                pleines.add(new Poubelle(
                    rs.getInt("id_poubelle"),
                    rs.getInt("id_emplacement"),
                    Couleur.valueOf(rs.getString("couleur"))
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return pleines;
    }
 // Vider la capacité actuelle de la poubelle
    public void viderPoubelle(int idPoubelle) {
        String sql = "UPDATE poubelle SET capacite_actuelle = 0 WHERE id_poubelle = ?";

        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, idPoubelle);
            statement.executeUpdate();
            System.out.println("✅ Poubelle vidée dans la base !");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
