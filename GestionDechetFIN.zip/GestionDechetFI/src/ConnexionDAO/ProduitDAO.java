package ConnexionDAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import ConnexionBDD.DatabaseConnection;
import gestionDechet.Produit;

public class ProduitDAO {

    // Ajouter un produit dans la base de données
    public void ajouterProduit(String nom, double prix, int idCategorie) {
        String query = "INSERT INTO produit (nom_produit, prix_produit, id_categorie) VALUES (?, ?, ?)";

        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, nom);
            stmt.setDouble(2, prix);
            stmt.setInt(3, idCategorie);

            stmt.executeUpdate();
            System.out.println("Produit ajouté avec succès !");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Récupérer les produits par commerce
    public List<Produit> getProduitsByCommerce(int idCommerce) {
        String query = "SELECT p.id_produit, p.nom_produit, p.prix_produit, p.id_categorie " +
                       "FROM produit p " +
                       "JOIN categorie c ON p.id_categorie = c.id_categorie " +
                       "WHERE c.id_commerce = ?";

        List<Produit> produits = new ArrayList<>();

        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, idCommerce);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int idProduit = rs.getInt("id_produit");
                String nomProduit = rs.getString("nom_produit");
                float prixProduit = rs.getFloat("prix_produit");

                // Créer un objet Produit et l'ajouter à la liste
                Produit produit = new Produit(idProduit, nomProduit, prixProduit);
                produits.add(produit);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return produits;
    }
}
