package ConnexionDAO;

import java.sql.*;
import gestionDechet.Compte;

public class CompteDAO {

    private Connection connection;

    public CompteDAO() {
        try {
            // Assurez-vous de remplacer ces valeurs par les vôtres
            String url = "jdbc:mysql://localhost:3306/nom_de_la_base_de_donnees";
            String username = "votre_utilisateur";
            String password = "votre_mot_de_passe";
            
            // Connexion à la base de données
            connection = DriverManager.getConnection(url, username, password);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Méthode pour récupérer un compte par email et mot de passe
    public Compte getCompteByEmailAndPassword(String email, String motDePasse) {
        Compte compte = null;
        try {
            String query = "SELECT * FROM comptes WHERE email = ? AND mot_de_passe = ?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, email);
            statement.setString(2, motDePasse);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                // Créez un objet Compte à partir des données récupérées
                int id = resultSet.getInt("id");
                String emailResult = resultSet.getString("email");
                String motDePasseResult = resultSet.getString("mot_de_passe");
                compte = new Compte(id, emailResult, motDePasseResult);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return compte;
    }
}
