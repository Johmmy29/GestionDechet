package ConnexionBDD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    // URL de la base de données
    private static final String URL = "jdbc:mysql://localhost:3306/gestion_dechets"; // Remplace 'gestion_dechets' par ton nom de base de données
    private static final String USER = "root"; // Utilisateur MySQL
    private static final String PASSWORD = "rootroot"; // Ton mot de passe MySQL

    // Méthode pour établir la connexion à la base de données
    public static Connection connect() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
