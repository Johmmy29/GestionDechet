package gestionDechet;

import javafx.beans.property.FloatProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleFloatProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

import java.util.ArrayList;
import java.util.List;

public class CategorieProduit {

    private final IntegerProperty idCategorie; // Utilisation des propriétés JavaFX pour lier à TableView
    private final StringProperty nom;          // Propriété de nom
    private final IntegerProperty pointsNecessaires; // Propriété des points nécessaires
    private final FloatProperty tauxReduction; // Propriété du taux de réduction
    private List<Produit> produits;

    public CategorieProduit(int idCategorie, String nom, int pointsNecessaires, float tauxReduction) {
        this.idCategorie = new SimpleIntegerProperty(idCategorie);
        this.nom = new SimpleStringProperty(nom);
        this.pointsNecessaires = new SimpleIntegerProperty(pointsNecessaires);
        this.tauxReduction = new SimpleFloatProperty(tauxReduction);
        this.produits = new ArrayList<>();
    }

    // Getter et Setter pour les propriétés
    public int getIdCategorie() {
        return idCategorie.get();
    }

    public void setIdCategorie(int idCategorie) {
        this.idCategorie.set(idCategorie);
    }

    public IntegerProperty idCategorieProperty() {
        return idCategorie;
    }

    public String getNom() {
        return nom.get();
    }

    public void setNom(String nom) {
        this.nom.set(nom);
    }

    public StringProperty nomProperty() {
        return nom;
    }

    public int getPointsNecessaires() {
        return pointsNecessaires.get();
    }

    public void setPointsNecessaires(int pointsNecessaires) {
        this.pointsNecessaires.set(pointsNecessaires);
    }

    public IntegerProperty pointsNecessairesProperty() {
        return pointsNecessaires;
    }

    public float getTauxReduction() {
        return tauxReduction.get();
    }

    public void setTauxReduction(float tauxReduction) {
        this.tauxReduction.set(tauxReduction);
    }

    public FloatProperty tauxReductionProperty() {
        return tauxReduction;
    }

    public List<Produit> getProduits() {
        return produits;
    }

    public void setProduits(List<Produit> produits) {
        this.produits = produits;
    }

    public void ajouterProduit(Produit produit) {
        produits.add(produit);
    }

    public boolean verifierReduction(int points) {
        if (points >= pointsNecessaires.get()) {
            System.out.println("\nVous avez assez de points pour appliquer la réduction");
        } else {
            System.out.println("\nVous n'avez pas encore assez de points pour appliquer la réduction");
        }
        return points >= pointsNecessaires.get();
    }

    public float appliquerReduction(float prix, int points) {
        if (verifierReduction(points)) {
            float reduction = prix * (tauxReduction.get() / 100);
            return prix - reduction;
        } else {
            return prix;
        }
    }

    @Override
    public String toString() {
        return "CategorieProduit{" +
                "idCategorie=" + idCategorie.get() +
                ", nom='" + nom.get() + '\'' +
                ", pointsNecessaires=" + pointsNecessaires.get() +
                ", tauxReduction=" + tauxReduction.get() +
                ", produits=" + produits +
                '}';
    }

    public void afficherPrixProduitParId(int idProduit) {
        for (Produit p : produits) {
            if (p.getIdProduit() == idProduit) {
                System.out.println("\nLe prix du produit est de : " + p.getPrix() + " €");
                return;
            }
        }
        System.out.println("\nLe produit cherché n'a pas été trouvé !");
    }

    public void afficherNomProduitParId(int idProduit) {
        for (Produit p : produits) {
            if (p.getIdProduit() == idProduit) {
                System.out.println("\nLe nom du produit avec l’ID " + idProduit + " est : " + p.getNom());
                return;
            }
        }
        System.out.println("\nAucun produit n'a été trouvé avec cette ID : " + idProduit);
    }
}
