package gestionDechet;

import java.util.ArrayList;
import java.util.List;

public class Commerce {
    private int idCommerce;
    private String nom;
    private String adresse;
    private String type;
    private List<CategorieProduit> categories = new ArrayList<>();
    private Contrat contrat;

    public Commerce() {
        // constructeur par défaut nécessaire pour JavaFX
    }

    public Commerce(int idCommerce, String nom, String adresse, String type) {
        this.idCommerce = idCommerce;
        this.nom = nom;
        this.adresse = adresse;
        this.type = type;
        this.categories = new ArrayList<>();
    }

    public int getIdCommerce() {
        return idCommerce;
    }

    public void setIdCommerce(int idCommerce) {
        this.idCommerce = idCommerce;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public List<CategorieProduit> getCategories() {
        return categories;
    }

    public void ajouterCategorie(CategorieProduit cat) {
        categories.add(cat);
    }

    public Contrat getContrat() {
        return contrat;
    }

    public void setContrat(Contrat contrat) {
        this.contrat = contrat;
    }

    public void afficherCategories() {
        System.out.println("Catégories du commerce " + nom + " :");
        for (CategorieProduit c : categories) {
            System.out.println("- " + c.getNom());
        }
    }

    public void afficherTousLesProduits() {
        System.out.println("Produits de " + nom + " :");
        for (CategorieProduit c : categories) {
            for (Produit p : c.getProduits()) {
                System.out.println("- " + p.getNom() + " | Prix : " + p.getPrix());
            }
        }
    }
}
