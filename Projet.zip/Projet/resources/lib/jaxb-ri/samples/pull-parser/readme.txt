This sample shows how you can combine a pull-parser with JAXB to
process XML in more flexible way.

