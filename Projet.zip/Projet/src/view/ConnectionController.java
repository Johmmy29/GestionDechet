package view;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class ConnectionController {
    
    @FXML
    private Button btnRetour;
    
    @FXML
    private Button btnValider;
    
    @FXML
    private void initialize() {
        btnRetour.setOnAction(event -> handleRetour());
    }
    
    private void handleRetour() {
        Stage stage = (Stage) btnRetour.getScene().getWindow();
        stage.close();
    }
}
