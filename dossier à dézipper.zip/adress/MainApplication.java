package adress;

import java.net.URL;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.Modality;
import javafx.scene.Node;
import view.InscriptionController;
import view.ConnectionController;

public class MainApplication extends Application {

    private Stage primaryStage;

    @Override
    public void start(Stage primaryStage) {
        this.primaryStage = primaryStage;
        this.primaryStage.setTitle("Projet GMF 4, groupe 1");
        
        showInscriptionOuConnection();
    }

    public void showInscriptionOuConnection() {
        try {
            URL fxmlUrl = getClass().getResource("/view/InscriptionOuConnection.fxml");
            if (fxmlUrl == null) {
                System.err.println("Impossible de trouver le fichier FXML");
                return;
            }
            
            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            loader.setController(null);
            
            BorderPane rootLayout = loader.load();
            
            Button exitButton = (Button) rootLayout.lookup("#btnRetour");
            if (exitButton != null) {
                exitButton.setOnAction(event -> Platform.exit());
            }
            
            for (Node node : rootLayout.lookupAll("Button")) {
                if (node instanceof Button) {
                    Button button = (Button) node;
                    if ("Inscription".equals(button.getText())) {
                        button.setOnAction(event -> openInscriptionWindow());
                    } else if ("Connection".equals(button.getText())) {
                        button.setOnAction(event -> openConnectionWindow());
                    }
                }
            }
            
            Scene scene = new Scene(rootLayout);
            primaryStage.setScene(scene);
            primaryStage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void openInscriptionWindow() {
        try {
            Stage inscriptionStage = new Stage();
            inscriptionStage.setTitle("Inscription");
            
            inscriptionStage.initModality(Modality.WINDOW_MODAL);
            inscriptionStage.initOwner(primaryStage);
            
            URL fxmlUrl = getClass().getResource("/view/Inscription.fxml");
            if (fxmlUrl == null) {
                System.err.println("Impossible de trouver le fichier FXML Inscription");
                return;
            }
            
            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            
            loader.setController(new InscriptionController());
            
            AnchorPane inscriptionLayout = loader.load();
            
            Scene scene = new Scene(inscriptionLayout);
            inscriptionStage.setScene(scene);
            inscriptionStage.showAndWait();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void openConnectionWindow() {
        try {
            Stage connectionStage = new Stage();
            connectionStage.setTitle("Connection");
            
            connectionStage.initModality(Modality.WINDOW_MODAL);
            connectionStage.initOwner(primaryStage);
            
            URL fxmlUrl = getClass().getResource("/view/Connection.fxml");
            if (fxmlUrl == null) {
                System.err.println("Impossible de trouver le fichier FXML Connection");
                return;
            }
            
            FXMLLoader loader = new FXMLLoader(fxmlUrl);
            
            loader.setController(new ConnectionController());
            
            AnchorPane connectionLayout = loader.load();
            
            Scene scene = new Scene(connectionLayout);
            connectionStage.setScene(scene);
            connectionStage.showAndWait();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args); 
    }
}